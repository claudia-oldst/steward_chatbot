
// This service connects to the OpenAI API

export const generateChatCompletion = async (prompt: string): Promise<string> => {
  console.log("Generating chat completion for prompt:", prompt);
  
  // First check for environment variable, then fallback to localStorage
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY || localStorage.getItem('openai-api-key');
  
  if (!apiKey) {
    throw new Error("OpenAI API key not found. Please set your API key in the settings or as VITE_OPENAI_API_KEY environment variable.");
  }
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful assistant for tenants with housing issues. Provide clear, concise solutions to common tenant problems. Be informative and practical.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      console.error("OpenAI API error:", errorData);
      throw new Error(`OpenAI API error: ${errorData.error?.message || 'Unknown error'}`);
    }
    
    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error("Error calling OpenAI API:", error);
    throw error;
  }
};
