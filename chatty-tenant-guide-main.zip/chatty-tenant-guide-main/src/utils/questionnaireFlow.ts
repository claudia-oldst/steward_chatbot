type QuestionData = {
  question: string;
  type: "multiple-choice" | "text-input";
  options?: { label: string; value: string }[];
};

export const getFollowUpQuestion = (
  initialIssue: string,
  previousResponses: Record<string, string>
): QuestionData => {
  // Initialize questionnaire flow
  const questionCount = Object.keys(previousResponses).length;
  
  // Start with tenant type question
  if (questionCount === 0) {
    return {
      question: "Are you an existing tenant?",
      type: "multiple-choice",
      options: [
        { label: "Yes, I'm an existing tenant", value: "existing" },
        { label: "No, I'm interested in renting", value: "prospective" }
      ]
    };
  }
  
  // Get the last question and answer
  const lastQuestion = Object.keys(previousResponses)[questionCount - 1];
  const lastAnswer = previousResponses[lastQuestion];
  
  // Handle path based on whether they're an existing tenant or prospective
  const tenantType = previousResponses["Are you an existing tenant?"];
  
  // Path for prospective tenants
  if (tenantType === "prospective") {
    return handleProspectiveTenantFlow(lastQuestion, lastAnswer, previousResponses);
  }
  
  // Path for existing tenants
  if (tenantType === "existing") {
    return handleExistingTenantFlow(lastQuestion, lastAnswer, previousResponses, initialIssue);
  }
  
  // Fallback
  return {
    question: "Is there anything else you'd like to add about your inquiry?",
    type: "text-input"
  };
};

const handleProspectiveTenantFlow = (
  lastQuestion: string,
  lastAnswer: string,
  previousResponses: Record<string, string>
): QuestionData => {
  if (lastQuestion === "Are you an existing tenant?") {
    return {
      question: "Would you like to inquire about renting a spare room?",
      type: "multiple-choice",
      options: [
        { label: "Yes", value: "yes" },
        { label: "No", value: "no" }
      ]
    };
  }
  
  if (lastQuestion === "Would you like to inquire about renting a spare room?") {
    if (lastAnswer === "no") {
      return {
        question: "How can we assist you today?",
        type: "text-input"
      };
    }
    
    // If they want to rent, start the rental questionnaire
    return {
      question: "May I know what you do for work?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "May I know what you do for work?") {
    return {
      question: "When do you need to move by?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "When do you need to move by?") {
    return {
      question: "How long are you looking to stay for?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "How long are you looking to stay for?") {
    return {
      question: "What is your current salary?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "What is your current salary?") {
    return {
      question: "Is there anything else you'd like to add to your rental inquiry?",
      type: "text-input"
    };
  }
  
  if (lastQuestion.includes("anything else you'd like to add")) {
    return {
      question: "Thank you for your information! Would you like to submit this inquiry?",
      type: "multiple-choice",
      options: [
        { label: "Yes, submit my inquiry", value: "yes" },
        { label: "No, I'll inquire later", value: "no" }
      ]
    };
  }
  
  // Final question
  return { question: "", type: "text-input" };
};

const handleExistingTenantFlow = (
  lastQuestion: string,
  lastAnswer: string,
  previousResponses: Record<string, string>,
  initialIssue: string
): QuestionData => {
  if (lastQuestion === "Are you an existing tenant?") {
    return {
      question: "What is your apartment block?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "What is your apartment block?") {
    return {
      question: "What is your apartment number?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "What is your apartment number?") {
    return {
      question: "What is your email address?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "What is your email address?") {
    return {
      question: "What is your phone number?",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "What is your phone number?") {
    return {
      question: "What is your issue about?",
      type: "multiple-choice",
      options: [
        { label: "🚰 Plumbing", value: "plumbing" },
        { label: "🔌 Electrical", value: "electrical" },
        { label: "🚪 Locks & Security", value: "security" },
        { label: "❄️ Heating & Cooling", value: "hvac" },
        { label: "🛠️ Other", value: "other" }
      ]
    };
  }
  
  if (lastQuestion === "What is your issue about?") {
    // Now we need to get the detailed issue description
    return {
      question: "Please describe your issue in detail:",
      type: "text-input"
    };
  }
  
  if (lastQuestion === "Please describe your issue in detail:") {
    // Final question before generating a response
    return {
      question: "Is there anything else you'd like to add about your issue?",
      type: "text-input"
    };
  }
  
  // Return empty question to indicate we're ready to provide a solution
  // This replaces the confirmation question
  return { question: "", type: "text-input" };
};
