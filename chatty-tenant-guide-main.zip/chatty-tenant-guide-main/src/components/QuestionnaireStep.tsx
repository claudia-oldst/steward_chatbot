
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type Option = {
  label: string;
  value: string;
};

type QuestionnaireStepProps = {
  question: string;
  type: "multiple-choice" | "text-input";
  options?: Option[];
  onAnswer: (answer: string) => void;
};

const QuestionnaireStep: React.FC<QuestionnaireStepProps> = ({
  question,
  type,
  options = [],
  onAnswer,
}) => {
  const [textInput, setTextInput] = useState("");
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  
  // Reset selected option when question changes
  useEffect(() => {
    setSelectedOption(null);
  }, [question]);

  const handleSubmitText = () => {
    if (textInput.trim()) {
      onAnswer(textInput);
      setTextInput("");
    }
  };

  const handleSkip = () => {
    onAnswer(""); // Submit an empty string when user skips
  };

  const handleOptionSelect = (value: string) => {
    setSelectedOption(value);
    onAnswer(value);
  };

  return (
    <motion.div
      className="w-full max-w-xl mx-auto my-4 glass-panel p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      <h3 className="text-lg font-medium mb-4">{question}</h3>

      {type === "multiple-choice" && (
        <div className="space-y-3">
          {options.map((option) => (
            <motion.div
              key={`option-${option.value}`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left h-auto py-3 px-4 transition-all",
                  selectedOption === option.value
                    ? "border-primary/50 bg-primary/5"
                    : "border-border"
                )}
                onClick={() => handleOptionSelect(option.value)}
              >
                {option.label}
              </Button>
            </motion.div>
          ))}
        </div>
      )}

      {type === "text-input" && (
        <div className="space-y-3">
          <Input
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            placeholder="Type your answer here..."
            className="input-field"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSubmitText();
              }
            }}
          />
          <div className="flex space-x-2">
            <Button
              className="button-primary flex-1"
              onClick={handleSubmitText}
              disabled={!textInput.trim()}
            >
              Continue
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={handleSkip}
            >
              Skip
            </Button>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default QuestionnaireStep;
