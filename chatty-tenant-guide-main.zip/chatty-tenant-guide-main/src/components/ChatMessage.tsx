
import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type ChatMessageProps = {
  message: string;
  type: "user" | "bot";
  isLoading?: boolean;
};

const ChatMessage: React.FC<ChatMessageProps> = ({ message, type, isLoading = false }) => {
  return (
    <motion.div
      className={cn(
        "my-2 max-w-[80%] p-4 rounded-2xl",
        type === "user" 
          ? "ml-auto bg-primary text-primary-foreground" 
          : "mr-auto glass-panel"
      )}
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
    >
      {message}
    </motion.div>
  );
};

export default ChatMessage;
