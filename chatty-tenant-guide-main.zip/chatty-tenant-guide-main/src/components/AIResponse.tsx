
import React from "react";
import { motion } from "framer-motion";
import LoadingDots from "./LoadingDots";

type AIResponseProps = {
  response: string;
  isLoading: boolean;
};

const AIResponse: React.FC<AIResponseProps> = ({ response, isLoading }) => {
  return (
    <motion.div
      className="glass-panel p-6 my-6 max-w-2xl mx-auto"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut", delay: 0.2 }}
    >
      <h3 className="text-lg font-medium mb-2">Solution</h3>
      
      {isLoading ? (
        <div className="p-4 rounded-md bg-secondary/50 min-h-[80px] flex items-center justify-center">
          <LoadingDots />
          <span className="ml-3 text-muted-foreground">Generating solution...</span>
        </div>
      ) : (
        <div className="prose prose-slate max-w-none">
          {response.split('\n').map((paragraph, i) => (
            <p key={i} className="mb-3 leading-relaxed">
              {paragraph}
            </p>
          ))}
        </div>
      )}
    </motion.div>
  );
};

export default AIResponse;
