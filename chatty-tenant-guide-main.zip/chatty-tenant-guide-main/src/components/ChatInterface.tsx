import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import ChatMessage from "./ChatMessage";
import QuestionnaireStep from "./QuestionnaireStep";
import AIResponse from "./AIResponse";
import LoadingDots from "./LoadingDots";
import ApiKeySettings from "./ApiKeySettings";
import { generateChatCompletion } from "@/utils/openaiService";
import { getFollowUpQuestion } from "@/utils/questionnaireFlow";
import { supabase } from "@/integrations/supabase/client";
import { Droplet, Thermometer, AlarmSmoke } from "lucide-react";

type Message = {
  id: string;
  content: string;
  type: "user" | "bot";
};

type ChatState = "questioning" | "generating" | "complete";

type CommonIssueOption = {
  label: string;
  value: string;
  icon: React.ReactNode;
};

const commonIssues: CommonIssueOption[] = [
  { 
    label: "Clogged Drain", 
    value: "My sink/bathtub drain is clogged and won't drain properly", 
    icon: <Droplet className="mr-2 h-5 w-5" /> 
  },
  { 
    label: "Heating Not Working", 
    value: "My heating system isn't working or isn't heating properly", 
    icon: <Thermometer className="mr-2 h-5 w-5" /> 
  },
  { 
    label: "Smoke Detector Beeping", 
    value: "My smoke detector is beeping intermittently", 
    icon: <AlarmSmoke className="mr-2 h-5 w-5" /> 
  }
];

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatState, setChatState] = useState<ChatState>("questioning");
  const [currentQuestion, setCurrentQuestion] = useState("");
  const [questionType, setQuestionType] = useState<"multiple-choice" | "text-input">("multiple-choice");
  const [questionOptions, setQuestionOptions] = useState<{ label: string; value: string }[]>([]);
  const [userResponses, setUserResponses] = useState<Record<string, string>>({});
  const [aiResponse, setAiResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [initialIssue, setInitialIssue] = useState("");
  const [isSavingToSupabase, setIsSavingToSupabase] = useState(false);

  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Start the questionnaire automatically when component mounts
  useEffect(() => {
    startQuestionnaire();
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const startQuestionnaire = () => {
    // Set initial question about tenant type
    const { question, type, options } = getFollowUpQuestion("", {});
    setCurrentQuestion(question);
    setQuestionType(type);
    setQuestionOptions(options || []);
    
    // Add the question as a bot message
    addMessage(question, "bot");
  };

  const handleAnswer = async (answer: string) => {
    // Add the user's answer to messages
    if (answer.trim()) {
      addMessage(answer, "user");
    }
    
    // Store the answer for context
    const updatedResponses = {
      ...userResponses,
      [currentQuestion]: answer,
    };
    setUserResponses(updatedResponses);

    console.log("============================")
    console.log("updatedResponses", updatedResponses)
    
    // Check if this is a final confirmation for submission
    if (currentQuestion === "Thank you for your information! Would you like to submit this inquiry?") {
      if (answer === "yes") {

        // here

        await saveInquiryToSupabase(updatedResponses, "prospective");
        addMessage("Your rental inquiry has been submitted. We'll be in touch soon!", "bot");
        setChatState("complete");
      } else {
        addMessage("No problem! Your inquiry wasn't submitted. Feel free to start a new chat when you're ready.", "bot");
        setChatState("complete");
      }
      return;
    }
    
    // Determine if we need more questions
    const nextQuestion = getFollowUpQuestion(initialIssue, updatedResponses);
    
    if (nextQuestion.question) {
      // We have more questions to ask
      setCurrentQuestion(nextQuestion.question);
      setQuestionType(nextQuestion.type);
      setQuestionOptions(nextQuestion.options || []);
      
      // Add the question as a bot message
      addMessage(nextQuestion.question, "bot");
    } else {
      // Empty question means we should proceed directly to generating AI response
      // for existing tenant issues
      const tenantType = updatedResponses["Are you an existing tenant?"];
      
      if (tenantType === "existing") {
        // Save the inquiry to Supabase before generating response
        const newEntry = await saveInquiryToSupabase({
          inquiry: updatedResponses["What is your issue about?"] + ' ' + updatedResponses["Please describe your issue in detail:"] + ' ' + updatedResponses["Is there anything else you'd like to add about your issue?"],
          contact_number: updatedResponses["What is your phone number?"],
          email: updatedResponses["What is your email address?"],
          status: "pending",
          priority: "medium",
        }, "existing");
        console.log('AYO')
        console.log(newEntry)
        // Generate AI response without asking for confirmation
        generateAIResponse();
      } else {
        // This is a fallback, should not typically be reached
        setChatState("complete");
        addMessage("Thank you for your information!", "bot");
      }
    }
  };

  const saveInquiryToSupabase = async (inquiry: {
    inquiry: string;
    contact_number: string;
    email: string;
    status: string;
    priority: string;
  }, tenantType: "existing" | "prospective") => {
    setIsSavingToSupabase(true);

    console.log("saveInquiryToSupabase")
    console.log("inquiry", inquiry)
    console.log("tenantType", tenantType) 

    const isExistingTenant = tenantType === "existing";
    
    console.log("Saving");
    // Create the record
    try {
      const entry = await supabase
        .from('Inquiries')
        .insert([
          {
            type: isExistingTenant ? "maintenance" : "rental",
            contact_number: inquiry.contact_number,
            email: inquiry.email,
            inquiry: inquiry.inquiry,
            status: inquiry.status,
            priority: inquiry.priority,
          }
        ]);

      console.log("entry", entry);
    } catch (error) {
      console.log("error", error);
    }

    console.log("Saved");
    
    toast({
      title: isExistingTenant ? "Issue logged successfully" : "Inquiry submitted successfully",
      description: isExistingTenant 
        ? "We've received your maintenance request." 
        : "We've received your rental inquiry.",
    });
    
    // try {
    //   const isExistingTenant = tenantType === "existing";
      
    //   // Extract relevant information based on tenant type
    //   const tenantDetails = isExistingTenant
    //     ? {
    //         apartment_block: responses["What is your apartment block?"] || "",
    //         apartment_number: responses["What is your apartment number?"] || "",
    //         email: responses["What is your email address?"] || "",
    //         phone: responses["What is your phone number?"] || "",
    //       }
    //     : {
    //         occupation: responses["May I know what you do for work?"] || "",
    //         move_by_date: responses["When do you need to move by?"] || "",
    //         stay_duration: responses["How long are you looking to stay for?"] || "",
    //         salary: responses["What is your current salary?"] || "",
    //       };
      
    //   // Determine issue type and description
    //   const issueType = isExistingTenant
    //     ? responses["What is your issue about?"] || "general"
    //     : "rental_inquiry";
        
    //   const issueDescription = isExistingTenant
    //     ? responses["Please describe your issue in detail:"] || initialIssue
    //     : initialIssue;
        
    //   // Additional notes
    //   const additionalNotes = isExistingTenant
    //     ? responses["Is there anything else you'd like to add about your issue?"] || ""
    //     : responses["Is there anything else you'd like to add to your rental inquiry?"] || "";
      
    //   // Create the record
    //   const { error } = await supabase
    //     .from('tenant_issues')
    //     .insert([
    //       { 
    //         tenant_type: tenantType,
    //         issue_type: issueType,
    //         issue_description: issueDescription,
    //         additional_notes: additionalNotes,
    //         tenant_details: tenantDetails,
    //         status: 'pending',
    //       }
    //     ]);
      
    //   if (error) throw error;
      
    //   toast({
    //     title: isExistingTenant ? "Issue logged successfully" : "Inquiry submitted successfully",
    //     description: isExistingTenant 
    //       ? "We've received your maintenance request." 
    //       : "We've received your rental inquiry.",
    //   });
      
    // } catch (error) {
    //   console.error("Error saving to Supabase:", error);
    //   toast({
    //     title: "Error",
    //     description: "There was an error saving your information. Please try again.",
    //     variant: "destructive",
    //   });
    // } finally {
    //   setIsSavingToSupabase(false);
    // }
  };

  const generateAIResponse = async () => {
    setChatState("generating");
    setIsLoading(true);
    
    try {
      // Check if API key exists
      const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
      console.log("apiKey", apiKey)
      if (!apiKey) {
        toast({
          title: "API Key Required",
          description: "Please set your OpenAI API key in the settings first.",
          variant: "destructive",
        });
        setChatState("questioning");
        setIsLoading(false);
        return;
      }
      
      // Format all questions and answers for the AI
      const formattedPrompt = formatPromptForOpenAI();
            
      // Get AI response
      const response = await generateChatCompletion(formattedPrompt);
      console.log("response", response)
      setAiResponse(response);
      addMessage("Here's a solution for your issue:", "bot");
      setChatState("complete");
    } catch (error) {
      console.error("Error generating AI response:", error);
      let errorMessage = "Sorry, I'm having trouble generating a response.";
      
      if (error instanceof Error) {
        // If it's an API key issue, provide more guidance
        if (error.message.includes("API key")) {
          errorMessage += " Please check your OpenAI API key in the settings.";
        } else {
          errorMessage += " Please try again later.";
        }
      }
      
      addMessage(errorMessage, "bot");
      setChatState("complete");
    } finally {
      setIsLoading(false);
    }
  };

  const formatPromptForOpenAI = (): string => {
    let prompt = "This issue is automatically recorded and can be viewed by the landlord.";
    
    // Add tenant information
    const tenantBlock = userResponses["What is your apartment block?"] || "";
    const tenantUnit = userResponses["What is your apartment number?"] || "";
    
    prompt += `I'm a tenant in apartment ${tenantUnit}, building ${tenantBlock} with this issue: `;
    
    // Add issue type and description
    const issueType = userResponses["What is your issue about?"] || "";
    const issueDescription = userResponses["Please describe your issue in detail:"] || initialIssue;
    
    prompt += `Issue type: ${issueType}\nIssue description: ${issueDescription}\n\n`;
    
    // Add additional information if provided
    const additionalInfo = userResponses["Is there anything else you'd like to add about your issue?"];
    if (additionalInfo && additionalInfo.trim()) {
      prompt += `Additional details: ${additionalInfo}\n\n`;
    }
    
    prompt += "Please provide a detailed solution for my issue. Include step-by-step instructions if applicable.";
    
    return prompt;
  };

  const addMessage = (content: string, type: "user" | "bot") => {
    const newMessage = {
      id: Date.now().toString(),
      content,
      type,
    };
    
    setMessages((prevMessages) => [...prevMessages, newMessage]);
  };

  const resetChat = () => {
    setMessages([]);
    setUserResponses({});
    setAiResponse("");
    setChatState("questioning");
    setInitialIssue("");
    startQuestionnaire();
  };

  return (
    <motion.div 
      className="w-full max-w-4xl mx-auto"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <ApiKeySettings />
      
      <div className="relative">
        <div className="glass-panel p-6 mb-6">
          <div className="mb-4 max-h-[400px] overflow-y-auto pr-2">
            {messages.map((message) => (
              <ChatMessage
                key={message.id}
                message={message.content}
                type={message.type}
              />
            ))}
            {(isLoading || isSavingToSupabase) && (
              <div className="my-2 max-w-[80%] mr-auto glass-panel p-4 rounded-2xl">
                <LoadingDots />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {chatState === "questioning" && (
            <QuestionnaireStep
              question={currentQuestion}
              type={questionType}
              options={questionOptions}
              onAnswer={handleAnswer}
            />
          )}
        </div>

        {chatState === "complete" && aiResponse && (
          <AIResponse response={aiResponse} isLoading={isLoading} />
        )}

        <div className="text-center mt-8">
          <Button 
            onClick={resetChat}
            variant="outline"
            className="hover:bg-primary/5"
          >
            Start New Chat
          </Button>
          {/* <Button
            onClick={() => saveInquiryToSupabase({
              "Are you an existing tenant?": "existing",
              "What is your apartment block?": "riverside",
              "What is your apartment number?": "21",
              "What is your email address?": "t@t.com",
              "What is your phone number?": "123"
            }, "existing")}
            ></Button> */}
        </div>
      </div>
    </motion.div>
  );
};

export default ChatInterface;
