
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Building, MessageSquare, Home } from "lucide-react";
import { cn } from "@/lib/utils";

const Navbar: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="w-full bg-white border-b shadow-sm mb-6">
      <div className="max-w-5xl mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Building className="h-6 w-6 text-primary mr-2" />
              <span className="text-lg font-semibold">Tenant Portal</span>
            </div>
            
            <div className="flex space-x-4 ml-6">
              <Link
                to="/"
                className={cn(
                  "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
                  isActive("/")
                    ? "bg-primary/10 text-primary"
                    : "text-gray-600 hover:bg-primary/5 hover:text-primary"
                )}
              >
                <Home className="h-4 w-4 mr-2" />
                Home
              </Link>
              <Link
                to="/issues"
                className={cn(
                  "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
                  isActive("/issues")
                    ? "bg-primary/10 text-primary"
                    : "text-gray-600 hover:bg-primary/5 hover:text-primary"
                )}
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                Issues
              </Link>
            </div>
          </div>
          
          {/* Empty div to maintain justify-between spacing */}
          <div></div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
