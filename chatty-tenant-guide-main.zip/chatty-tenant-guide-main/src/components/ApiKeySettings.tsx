
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";

const ApiKeySettings: React.FC = () => {
  const [apiKey, setApiKey] = useState("");
  const [isVisible, setIsVisible] = useState(false);
  const [usingEnvVar, setUsingEnvVar] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Check if API key is set via environment variable
    const envApiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (envApiKey) {
      setUsingEnvVar(true);
    } else {
      // Load the API key from localStorage if it exists
      const savedApiKey = localStorage.getItem("openai-api-key");
      if (savedApiKey) {
        setApiKey(savedApiKey);
      }
    }
  }, []);

  const saveApiKey = () => {
    if (!apiKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter your OpenAI API key",
        variant: "destructive",
      });
      return;
    }

    localStorage.setItem("openai-api-key", apiKey);
    toast({
      title: "Success",
      description: "Your OpenAI API key has been saved",
    });
    setIsVisible(false);
  };

  return (
    <div className="fixed top-4 right-4 z-50">
      <Button 
        variant="outline"
        className="hover:bg-primary/5"
        onClick={() => setIsVisible(!isVisible)}
      >
        {isVisible ? "Close" : "API Settings"}
      </Button>

      {isVisible && (
        <motion.div
          className="absolute top-12 right-0 glass-panel p-4 w-80"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          <h3 className="text-lg font-medium mb-2">OpenAI API Settings</h3>
          
          {usingEnvVar ? (
            <div className="mb-4">
              <div className="bg-green-50 p-3 rounded-md border border-green-200">
                <p className="text-sm text-green-800">
                  Using API key from environment variable (VITE_OPENAI_API_KEY)
                </p>
              </div>
            </div>
          ) : (
            <>
              <p className="text-sm text-gray-500 mb-4">
                Enter your OpenAI API key to connect to the service.
                Get your API key from{" "}
                <a
                  href="https://platform.openai.com/api-keys"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary underline"
                >
                  OpenAI's dashboard
                </a>
                .
              </p>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="apiKey" className="text-sm font-medium">
                    API Key
                  </label>
                  <Input
                    id="apiKey"
                    type="password"
                    placeholder="sk-..."
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="mt-1 w-full"
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button 
                    variant="outline"
                    onClick={() => setIsVisible(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={saveApiKey}>
                    Save Key
                  </Button>
                </div>
              </div>
              
              <div className="mt-4 pt-3 border-t border-gray-200">
                <p className="text-xs text-gray-500">
                  Alternatively, you can set the VITE_OPENAI_API_KEY environment variable
                  in your deployment environment.
                </p>
              </div>
            </>
          )}
        </motion.div>
      )}
    </div>
  );
};

export default ApiKeySettings;
