
import { motion } from "framer-motion";

const ChatHeader = () => {
  return (
    <motion.header 
      className="text-center px-8 pt-8 pb-4"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div className="chip bg-primary/10 text-primary mb-3">Tenant Assistant</div>
      <h1 className="text-3xl font-bold mb-2 tracking-tight">Tenant Assistance</h1>
      <p className="text-muted-foreground max-w-2xl mx-auto">
        We'll help you with your apartment needs, whether you're an existing tenant or looking to rent.
      </p>
    </motion.header>
  );
};

export default ChatHeader;
