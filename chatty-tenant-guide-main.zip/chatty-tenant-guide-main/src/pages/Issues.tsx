import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import LoadingDots from "@/components/LoadingDots";
import { supabase } from "@/integrations/supabase/client";

type Issue = {
  id: number;
  created_at: string;
  tenant_type: string;
  issue_type: string;
  issue_description: string;
  status: string;
  tenant_details: {
    email?: string;
    phone?: string;
    apartment_block?: string;
    apartment_number?: string;
    occupation?: string;
    move_by_date?: string;
    stay_duration?: string;
    salary?: string;
  };
};

const Issues = () => {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchIssues = async () => {
      try {
        setLoading(true);
        
        const { data, error } = await supabase
          .from('tenant_issues')
          .select('*')
          .order('created_at', { ascending: false });
          
        if (error) throw error;
        
        setIssues(data || []);
      } catch (err) {
        console.error("Error fetching issues:", err);
        setError(err instanceof Error ? err.message : "Failed to load issues");
      } finally {
        setLoading(false);
      }
    };

    fetchIssues();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="container px-4 py-6 max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <h1 className="text-2xl font-bold mb-6">Past Issues &amp; Inquiries</h1>
        
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {loading ? (
          <div className="flex justify-center items-center h-40">
            <LoadingDots />
          </div>
        ) : issues.length > 0 ? (
          <div className="glass-panel p-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {issues.map((issue) => (
                  <TableRow key={issue.id}>
                    <TableCell>{formatDate(issue.created_at)}</TableCell>
                    <TableCell>{issue.issue_type}</TableCell>
                    <TableCell className="max-w-xs truncate">{issue.issue_description}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        issue.status === 'pending' 
                          ? 'bg-yellow-100 text-yellow-800' 
                          : issue.status === 'resolved'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-blue-100 text-blue-800'
                      }`}>
                        {issue.status.charAt(0).toUpperCase() + issue.status.slice(1)}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="glass-panel p-6 text-center">
            <p className="text-muted-foreground">No past issues or inquiries found.</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default Issues;
