
import React from "react";
import { motion } from "framer-motion";
import ChatHeader from "@/components/ChatHeader";
import ChatInterface from "@/components/ChatInterface";

const Index = () => {
  return (
    <div className="px-4 py-6">
      <motion.div
        className="max-w-5xl mx-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <ChatHeader />
        <ChatInterface />
        
        <footer className="text-center text-sm text-muted-foreground mt-16 pb-8">
          <p>© {new Date().getFullYear()} Tenant Assistance Bot • All rights reserved</p>
        </footer>
      </motion.div>
    </div>
  );
};

export default Index;
