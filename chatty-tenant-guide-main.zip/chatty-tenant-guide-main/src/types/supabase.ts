
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      tenant_issues: {
        Row: {
          id: number
          created_at: string
          tenant_type: string
          issue_type: string
          issue_description: string
          additional_notes: string | null
          tenant_details: Json
          status: string
        }
        Insert: {
          id?: number
          created_at?: string
          tenant_type: string
          issue_type: string
          issue_description: string
          additional_notes?: string | null
          tenant_details: Json
          status: string
        }
        Update: {
          id?: number
          created_at?: string
          tenant_type?: string
          issue_type?: string
          issue_description?: string
          additional_notes?: string | null
          tenant_details?: Json
          status?: string
        }
      }
    }
  }
}
